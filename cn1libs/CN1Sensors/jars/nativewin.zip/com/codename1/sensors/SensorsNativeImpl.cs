namespace com.codename1.sensors{

using System;
using System.Windows;

public class SensorsNativeImpl {
    public void init(int param) {
    }

    public void setSamplingRate(int param) {
    }

    public void deregisterListener(int param) {
    }

    public void registerListener(int param) {
    }

    public bool isSupported() {
        return false;
    }

}
}
