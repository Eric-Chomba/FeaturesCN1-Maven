package com.codename1.sensors;

public class SensorsNativeImpl implements com.codename1.sensors.SensorsNative{
    public void init(int param) {
    }

    public void setSamplingRate(int param) {
    }

    public void deregisterListener(int param) {
    }

    public void registerListener(int param) {
    }

    public boolean isSupported() {
        return false;
    }

}
