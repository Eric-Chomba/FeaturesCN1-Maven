(function(exports){

var o = {};

    o.addPassword__int_java_lang_String_java_lang_String_java_lang_String = function(param1, param2, param3, param4, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.deletePassword__int_java_lang_String_java_lang_String = function(param1, param2, param3, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.scan__java_lang_String = function(param1, callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.isAvailable_ = function(callback) {
        callback.error(new Error("Not implemented yet"));
    };

    o.getPassword__int_java_lang_String_java_lang_String = function(param1, param2, param3, callback) {
        callback.error(new Error("Not implemented yet"));
    };
    
    o.cancelRequest__int = function(requestId){};

    o.isSupported_ = function(callback) {
        callback.complete(false);
    };

exports.com_codename1_fingerprint_impl_InternalFingerprint= o;

})(cn1_get_native_interfaces());
