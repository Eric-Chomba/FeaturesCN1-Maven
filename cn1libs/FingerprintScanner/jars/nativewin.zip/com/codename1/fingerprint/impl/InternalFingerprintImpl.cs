namespace com.codename1.fingerprint.impl{


public class InternalFingerprintImpl : IInternalFingerprintImpl {
    public void addPassword(int param, String param1, String param2, String param3) {
    }

    public void deletePassword(int param, String param1, String param2) {
    }

    public void scan(String param) {
    }

    public bool isAvailable() {
        return false;
    }

    public void getPassword(int param, String param1, String param2) {
    }

    public bool isSupported() {
        return false;
    }

    public void cancelRequest(int requestId){}

}
}
