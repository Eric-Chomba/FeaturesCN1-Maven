namespace com.codename1.ext.codescan{

using System;
using System.Windows;

public class NativeCodeScannerImpl {
    public void scanQRCode() {
    }

    public void scanBarCode() {
    }

    public bool isSupported() {
        return false;
    }

}
}
