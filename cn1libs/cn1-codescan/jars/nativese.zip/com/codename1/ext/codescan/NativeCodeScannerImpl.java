package com.codename1.ext.codescan;

public class NativeCodeScannerImpl implements com.codename1.ext.codescan.NativeCodeScanner{
    public void scanQRCode() {
    }

    public void scanBarCode() {
    }

    public boolean isSupported() {
        return false;
    }

}
