#import <Foundation/Foundation.h>

@interface com_codename1_ext_codescan_NativeCodeScannerImpl : NSObject {
}

-(void)scanQRCode;
-(void)scanBarCode;
-(BOOL)isSupported;
@end
