#import <Foundation/Foundation.h>
#if !TARGET_IPHONE_SIMULATOR
#import "ZBarReaderViewController.h"

@interface CVZBarReaderViewControllerExt : ZBarReaderViewController
@end
#endif
